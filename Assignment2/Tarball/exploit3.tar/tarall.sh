#!/bin/bash



tar cvf exploit1_a.tar -C exploit1_a .
tar cvf exploit1_b.tar -C exploit1_b .
tar cvf exploit1_c.tar -C exploit1_c .
tar cvf exploit2.tar -C exploit2 .
tar cvf exploit3.tar -C exploit3 .

