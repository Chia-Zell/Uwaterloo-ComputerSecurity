	function  fn(content) {
		var aTags = document.querySelectorAll("a[href^='view.php?id=']");
		var foundTag;
			
			for (i = aTags.length-1; i >= 0; i--) {
						if(aTags[i].textContent==content){
					
					foundTag = aTags[i];
					
				  break;
				  }
				  
			}

			var test = foundTag.href;
			var res = test.match(/\d+$/g);
			var postID= res; 
			
		var str1 = "";

			var request = str1.concat("comment=test&form=comment&parent=",res,"&submit=Post");
			
			var xhr = new XMLHttpRequest();
			xhr.open("POST", 'post.php');
			
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

	xhr.onreadystatechange = function() {
		if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
		console.log("SENT");
	}
		}
	xhr.send(request); 
		}
		

	fn("Does anyone think this is a good idea?");

